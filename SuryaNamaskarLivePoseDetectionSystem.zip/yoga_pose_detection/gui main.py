# -*- coding: utf-8 -*-ss
"""
Created on Tue May  4 17:28:41 2021

@author: user
"""

from tkinter import *
import tkinter as tk


from PIL import Image ,ImageTk

from tkinter.ttk import *
from pymsgbox import *


root=tk.Tk()

root.title("Suryanamskar Pose Detection Using Machine Learning")
w,h = root.winfo_screenwidth(),root.winfo_screenheight()
w,h = root.winfo_screenwidth(),root.winfo_screenheight()
root.geometry("%dx%d+0+0"%(w,h))
img = Image.open("D:/23 Protech/100% code/Suryanamskar Pose/yoga_pose_detection/y1.ico")  # Replace with your image path
if img.size != (32, 32):
    img = img.resize((32, 32), Image.LANCZOS)
photo = ImageTk.PhotoImage(img)
root.iconphoto(False, photo)

image2 =Image.open('om.jpg')
image2 =image2.resize((1400,700))

background_image=ImageTk.PhotoImage(image2)

background_label = tk.Label(root, image=background_image)

background_label.image = background_image

background_label.place(x=0, y=0)
#, relwidth=1, relheight=1)



lbl = tk.Label(root, text="Calming the mind is yoga. Not just standing on the head.", font=('times', 25,' bold '), height=1, width=45,bg="white",fg="Purple")
lbl.place(x=250, y=0)

from tkinter import messagebox as ms


def Login():
    from subprocess import call
    call(["python","login.py"])
def Register():
    from subprocess import call
    call(["python","registration.py"])






d2=tk.Button(root,text="LOGIN",command=Login,width=12,height=1,bd=5,background="BLUE",foreground="WHITE",font=("times new roman",18,"bold"))
d2.place(x=1150,y=50)
d3=tk.Button(root,text="SIGN-UP",command=Register,width=12,height=1,bd=5,background="GREEN",foreground="WHITE",font=("times new roman",18,"bold"))
d3.place(x=1150,y=120)



root.mainloop()

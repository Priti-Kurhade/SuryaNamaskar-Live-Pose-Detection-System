import tkinter as tk
from tkinter import ttk, LEFT, END
from PIL import Image, ImageTk
from tkinter.filedialog import askopenfilename
from tkinter import messagebox as ms
import cv2
import sqlite3
import os
import numpy as np
import time
import tkinter as tk
from moviepy.editor import VideoFileClip

root = tk.Tk()
global fn
fn = ""
##############################################+=============================================================

root.configure(background="brown")
# root.geometry("1300x700")


w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry("%dx%d+0+0" % (w, h))
root.title("Suryanamskar Pose Detection Using Machine Learning")
img = Image.open("D:/23 Protech/100% code/Suryanamskar Pose/yoga_pose_detection/y1.ico")  # Replace with your image path
if img.size != (32, 32):
    img = img.resize((32, 32), Image.LANCZOS)
photo = ImageTk.PhotoImage(img)
root.iconphoto(False, photo)



image2 = Image.open('y3.jpg')
image2 = image2.resize((1400,700))

background_image = ImageTk.PhotoImage(image2)

background_label = tk.Label(root, image=background_image)

background_label.image = background_image

background_label.place(x=0, y=0)
label_l1 = tk.Label(root, text="Yoga is not a work-out, it is a work-in\nAnd this is the point of spiritual practice to open up your hearts",font=("Times New Roman", 25, 'bold italic'),
                    background="white", fg="black", width=75, height=2)
label_l1.place(x=0, y=0)

def play_video():
        
        cap = cv2.VideoCapture('D:/23 Protech/100% code/Suryanamskar Pose/yoga_pose_detection/yoga1.mp4')
         
        # Check if camera opened successfully
        if (cap.isOpened()== False): 
          print("Error opening video stream or file")
         
        # Read until video is completed
        while(cap.isOpened()):
          # Capture frame-by-frame
          ret, frame = cap.read()
          if ret == True:
         
            # Display the resulting frame
            cv2.imshow('Frame',frame)
            
            # Press Q on keyboard to  exit
            if cv2.waitKey(40) & 0xFF == ord('q'):
              break
         
          # Break the loop
          else: 
            break
         
        # When everything done, release the video capture object
        cap.release()
         
        # Closes all the frames
        cv2.destroyAllWindows()





################################$%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def action():
   
    from subprocess import call
    call(["python","GUI_Masters.py"])
    
#################################################################################################################
def window():
    root.destroy()

frame = tk.LabelFrame(root, text=" --Lets Begin-- ", width=250, height=350, bd=5, font=('times', 14, ' bold '),bg="black",fg="white")
frame.grid(row=0, column=0, sticky='nw')
frame.place(x=10, y=100)



button3 = tk.Button(frame, text="Detection",command=action, width=10, height=1, bg="white", fg="black",font=('times', 20, ' bold '))
button3.place(x=30, y=50)

button3 = tk.Button(frame, text="S-Video",command=play_video, width=10, height=1, bg="white", fg="black",font=('times', 20, ' bold '))
button3.place(x=30, y=150)

exit = tk.Button(frame, text="Exit", command=window, width=10, height=1, font=('times', 20, ' bold '), bg="red",fg="white")
exit.place(x=30, y=250)

root.mainloop()
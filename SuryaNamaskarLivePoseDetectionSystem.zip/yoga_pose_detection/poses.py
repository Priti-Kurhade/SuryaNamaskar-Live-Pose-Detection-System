# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 18:45:56 2024

@author: Yashraj Shinde
"""

import tkinter as tk
from tkinter import ttk, LEFT, END
from PIL import Image, ImageTk
from tkinter.filedialog import askopenfilename
from tkinter import messagebox as ms
import cv2
import sqlite3
import os
import numpy as np
import time
import tkinter as tk
from moviepy.editor import VideoFileClip

root = tk.Tk()
global fn
fn = ""
##############################################+=============================================================

root.configure(background="SeaGreen1")
# root.geometry("1300x700")


w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry("1000x700")
root.title("Suryanamskar and Yoga Pose Detection Using Machine Learning")
img = Image.open("D:/23 Protech/100% code/Suryanamskar Pose/yoga_pose_detection/y1.ico")  # Replace with your image path
if img.size != (32, 32):
    img = img.resize((32, 32), Image.LANCZOS)
photo = ImageTk.PhotoImage(img)
root.iconphoto(False, photo)


def help():
    frame_alpr = tk.LabelFrame(root, text=" --Yoga Poses-- ", width=900, height=550, bd=5, font=('times', 14, ' bold '),bg="SeaGreen1")
    frame_alpr.grid(row=0, column=0, sticky='nw')
    frame_alpr.place(x=50, y=120)

    image3 = Image.open('v.jpg')
    image3 = image3.resize((200, 200))
    background_image3 = ImageTk.PhotoImage(image3)
    background_label3 = tk.Label(root, image=background_image3,text="Vajrasan",compound='bottom')
    background_label3.image = background_image3
    background_label3.place(x=100, y=150)
    
    image4 = Image.open('sar.jpg')
    image4 = image4.resize((200, 200))
    background_image4 = ImageTk.PhotoImage(image4)
    background_label4 = tk.Label(root, image=background_image4,text="Sarvangasan",compound='bottom')
    background_label4.image = background_image4
    background_label4.place(x=300, y=150)
    
    
    image5 = Image.open('shi.jpg')
    image5 = image5.resize((200, 200))
    background_image5 = ImageTk.PhotoImage(image5)
    background_label5 = tk.Label(root, image=background_image5,text="Shirsasan",compound='bottom')
    background_label5.image = background_image5
    background_label5.place(x=500, y=150)
    
    image6 = Image.open('ch.jpg')
    image6 = image6.resize((200, 200))
    background_image6 = ImageTk.PhotoImage(image6)
    background_label6 = tk.Label(root, image=background_image6,text="Chakrasan",compound='bottom')
    background_label6.image = background_image6
    background_label6.place(x=700, y=150)
    
    image7 = Image.open('s.jpg')
    image7 = image7.resize((200, 200))
    background_image7 = ImageTk.PhotoImage(image7)
    background_label7 = tk.Label(root, image=background_image7,text="Shavasan",compound='bottom')
    background_label7.image = background_image7
    background_label7.place(x=100, y=400)
    
    image8 = Image.open('g.jpg')
    image8 = image8.resize((200, 200))
    background_image8 = ImageTk.PhotoImage(image8)
    background_label8 = tk.Label(root, image=background_image8,text="Gomukhaasan",compound='bottom')
    background_label8.image = background_image8
    background_label8.place(x=300, y=400)
    
    image9 = Image.open('b.jpg')
    image9 = image9.resize((200, 200))
    background_image9 = ImageTk.PhotoImage(image9)
    background_label9 = tk.Label(root, image=background_image9,text="Bhadraasan",compound='bottom')
    background_label9.image = background_image9
    background_label9.place(x=500, y=400)
    
    image10 = Image.open('d.jpg')
    image10 = image10.resize((200, 200))
    background_image10 = ImageTk.PhotoImage(image3)
    background_label10 = tk.Label(root, image=background_image10,text="Dhanurasan",compound='bottom')
    background_label10.image = background_image10
    background_label10.place(x=700, y=400)
    
button3 = tk.Button(root, text="Yoga Poses",command=help, width=10, height=1, bg="white", fg="black",font=('times', 20, ' bold '))
button3.place(x=350, y=0)   

root.mainloop()
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 17:34:56 2024

@author: Yashraj Shinde
"""

import tkinter as tk
from PIL import Image, ImageTk

root = tk.Tk()
root.title("Suryanamskar Pose Detection Using Machine Learning")
w,h = root.winfo_screenwidth(),root.winfo_screenheight()
root.geometry("%dx%d+0+0"%(w,h))
img = Image.open("D:/23 Protech/100% code/Suryanamskar Pose/yoga_pose_detection/y1.ico")  # Replace with your image path
if img.size != (32, 32):
    img = img.resize((32, 32), Image.LANCZOS)
photo = ImageTk.PhotoImage(img)
root.iconphoto(False, photo)


frame_alpr = tk.LabelFrame(root,width=1350, height=700, bd=5, font=('times', 14, 'bold'),bg="#152238")
frame_alpr.grid(row=0, column=0)
frame_alpr.place(x=0, y=0)

img = Image.open('y2.png')
img = img.resize((150,150), Image.LANCZOS)
logo_image = ImageTk.PhotoImage(img)

logo_label = tk.Label(root, image=logo_image)
logo_label.image = logo_image
logo_label.place(x=600, y=100)

lbl = tk.Label(root, text="Welcome to Suryanamskar Pose Detection \nUsing Machine Learning", font=('times', 25,' bold underline '), height=2, width=45,bg="#152238",fg="white")
lbl.place(x=250, y=300)

def start():
    from subprocess import call
    call(['python','gui main.py'])
    
btn = tk.Button(root, text="Let's Start", bg="Yellow",fg="Black",font=("",20), width=9, height=1, command=start)
btn.place(x=600, y=450)


root.mainloop()
# -*- coding: utf-8 -*-
"""
Created on Thu May 13 18:07:39 2021

@author: srcdo
"""
import mediapipe as mp # Import mediapipe
import cv2 # Import opencv
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline 
from sklearn.preprocessing import StandardScaler 
from sklearn.linear_model import LogisticRegression, RidgeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score # Accuracy metrics 
import pickle
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense


mp_drawing = mp.solutions.drawing_utils # Drawing helpers
mp_holistic = mp.solutions.holistic # Mediapipe Solutions

df = pd.read_csv('coordss.csv')

X = df.drop('class', axis=1) # features
y = df['class'] # target value


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1234)

# Reshape X_train and X_test for CNN input format
# X_train = X_train.values.reshape(-1, 9, 2, 1)
# X_test = X_test.values.reshape(-1, 9, 2, 1)

# # Define the CNN model
# cnn_model = Sequential()
# cnn_model.add(Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(9, 2, 1)))
# cnn_model.add(MaxPooling2D(pool_size=(2, 2)))
# cnn_model.add(Flatten())
# cnn_model.add(Dense(64, activation='relu'))
# cnn_model.add(Dense(3, activation='sigmoid'))

# # Compile the model
# cnn_model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# # Train the CNN model
# cnn_model.fit(X_train, y_train, epochs=10, batch_size=32)

# # Evaluate the model
# cnn_scores = cnn_model.evaluate(X_test, y_test, verbose=0)
# print('CNN Accuracy:', cnn_scores[1])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1234)
pipelines = {
    'lr':make_pipeline(StandardScaler(), LogisticRegression()),
    'rc':make_pipeline(StandardScaler(), RidgeClassifier()),
    'rf':make_pipeline(StandardScaler(), RandomForestClassifier()),
    'gb':make_pipeline(StandardScaler(), GradientBoostingClassifier()),
}
fit_models = {}
for algo, pipeline in pipelines.items():
    model = pipeline.fit(X_train, y_train)
    fit_models[algo] = model
print(fit_models)
fit_models['lr'].predict(X_test)




for algo, model in fit_models.items():
    yhat = model.predict(X_test)
    print(algo, accuracy_score(y_test, yhat))
    
fit_models['lr'].predict(X_test)
print(y_test)

with open('body_language.pkl1', 'wb') as f:
    pickle.dump(fit_models['lr'], f)
    

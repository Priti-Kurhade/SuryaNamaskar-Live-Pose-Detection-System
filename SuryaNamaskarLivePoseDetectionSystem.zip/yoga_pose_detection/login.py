import tkinter as tk
from tkinter import ttk, LEFT, END
from tkinter import messagebox as ms
import sqlite3
from PIL import Image, ImageTk
import re


##############################################+=============================================================
root = tk.Tk()
root.configure(background="white")
# root.geometry("1300x700")
img = Image.open("D:/23 Protech/100% code/Suryanamskar Pose/yoga_pose_detection/y1.ico")  # Replace with your image path
if img.size != (32, 32):
    img = img.resize((32, 32), Image.LANCZOS)
photo = ImageTk.PhotoImage(img)
root.iconphoto(False, photo)

w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry("550x400")
root.title("Login Form")




username = tk.StringVar()
password = tk.StringVar()
        

def registration():
    from subprocess import call
    call(["python","registration.py"])
    root.destroy()

def login():
        # Establish Connection

    with sqlite3.connect('evaluation.db') as db:
         c = db.cursor()

        # Find user If there is any take proper action
         db = sqlite3.connect('evaluation.db')
         cursor = db.cursor()
         cursor.execute("CREATE TABLE IF NOT EXISTS registration"
                           "(Fullname TEXT, address TEXT, username TEXT, Email TEXT, Phoneno TEXT,Gender TEXT,age TEXT , password TEXT)")
         db.commit()
         find_entry = ('SELECT * FROM registration WHERE username = ? and password = ?')
         c.execute(find_entry, [(username.get()), (password.get())])
         result = c.fetchall()

         if result:
            msg = ""
            # self.logf.pack_forget()
            # self.head['text'] = self.username.get() + '\n Loged In'
            # msg = self.head['text']
            #            self.head['pady'] = 150
            print(msg)
            ms.showinfo("messege", "you have successfully log-in")
            from subprocess import call
            call(['python','Home.py'])
            # ===========================================
            root.destroy()

            

            # ================================================
         else:
           ms.showerror('Oops!', 'Username Or Password Did Not Found/Match.')



title=tk.Label(root, text="Login Here", font=("Algerian", 30, "bold"),bd=5,bg="white",fg="blue")
title.place(x=150,y=50,width=250)
        
Login_frame=tk.Frame(root,bg="white")
Login_frame.place(x=50,y=130)
        
        
lbluser=tk.Label(Login_frame,text="Username",compound=LEFT,font=("Times new roman", 20, "bold"),bg="white").grid(row=1,column=0,padx=20,pady=10)
txtuser=tk.Entry(Login_frame,bd=5,textvariable=username,font=("",15))
txtuser.grid(row=1,column=1,padx=20)
        
lblpass=tk.Label(Login_frame,text="Password",compound=LEFT,font=("Times new roman", 20, "bold"),bg="white").grid(row=2,column=0,padx=50,pady=10)
txtpass=tk.Entry(Login_frame,bd=5,textvariable=password,show="*",font=("",15))
txtpass.grid(row=2,column=1,padx=20)
        
btn_log=tk.Button(Login_frame,text="SUBMIT",command=login,width=15,font=("Times new roman", 14, "bold"),bg="Green",fg="white")
btn_log.grid(row=3,column=1,pady=10)
btn_reg=tk.Button(Login_frame,text="SIGN-HERE",command=registration,width=15,font=("Times new roman", 14, "bold"),bg="red",fg="white")
btn_reg.grid(row=3,column=0,pady=10)
        
       

root.mainloop()
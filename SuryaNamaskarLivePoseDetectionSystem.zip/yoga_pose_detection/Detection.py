# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 12:06:56 2024

@author: Yashraj Shinde
"""

from tkinter import *
import tkinter as tk


from PIL import Image ,ImageTk

from tkinter.ttk import *
from pymsgbox import *


root=tk.Tk()

root.title("Yoga Pose Detection Using Machine Learning")
w,h = root.winfo_screenwidth(),root.winfo_screenheight()
w,h = root.winfo_screenwidth(),root.winfo_screenheight()
root.geometry("%dx%d+0+0"%(w,h))
img = Image.open("D:/23 Protech/100% code/Suryanamskar Pose/yoga_pose_detection/y1.ico")  # Replace with your image path
if img.size != (32, 32):
    img = img.resize((32, 32), Image.LANCZOS)
photo = ImageTk.PhotoImage(img)
root.iconphoto(False, photo)


image2 =Image.open('k3.jpg')
image2 =image2.resize((1400,700))

background_image=ImageTk.PhotoImage(image2)

background_label = tk.Label(root, image=background_image)

background_label.image = background_image

background_label.place(x=0, y=0)

lbl = tk.Label(root, text="The benefits of yoga is not for telling someone, rather you should do & feel it.", font=('times', 25,' bold '), height=1, width=75,bg="white",fg="Purple")
lbl.place(x=0, y=0)

def yoga():
   
    from subprocess import call
    call(["python","GUI_Master.py"])
    


def suryanamaskar():
   
    from subprocess import call
    call(["python","GUI_Masters.py"])



button3 = tk.Button(root, text="Yoga Detection",command=yoga, width=15, height=1, bg="yellow", fg="black",font=('times', 20, ' bold '))
button3.place(x=550, y=250)
button3 = tk.Button(root, text="Suryanamaskar Detection",command=suryanamaskar, width=20, height=1, bg="orange", fg="black",font=('times', 20, ' bold '))
button3.place(x=550, y=350)







root.mainloop()
